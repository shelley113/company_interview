<?php
require_once 'ShoppingCart.php';

class User
{
    private $name;
    private $emailAddress;
    private $shoppingCart;

    public function __construct($name, $emailAddress)
    {
        $this->name = $name;
        $this->emailAddress = $emailAddress;
        $this->shoppingCart = new ShoppingCart();
    }

    public function getName()
    {
        return $this->name;
    }

    public function getEmailAddress()
    {
        return $this->emailAddress;
    }

    public function getShoppingCart()
    {
        return $this->shoppingCart;
    }

}
?>
