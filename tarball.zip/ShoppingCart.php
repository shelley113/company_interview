<?php
require_once 'Product.php';

class ShoppingCart
{
    private $products;

    public function __construct() 
    {
        $this->products = array();
    }

    public function getProducts() 
    {
        return $this->products;
    }

    public function addProduct($addProduct)
    {
        array_push($this->products, $addProduct);
    }

    public function removeProduct($selectedProduct)
    {
        $flag = false;
        foreach($this->products as $i=>$value){
            if($value == $selectedProduct && !$flag){
                unset($this->products[$i]);
                $flag = true;
            }
        }
    }

    public function totalPrice() 
    {
        $totalPrice = 0;
        foreach($this->products as $value){
            $totalPrice = $totalPrice + $value->getPrice();
        }
        return $totalPrice;
    }
}
?>