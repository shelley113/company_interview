<?php
use PHPUnit\Framework\TestCase;

require_once 'ShoppingCart.php';
require_once 'User.php';
require_once 'Product.php';

class Test extends TestCase
{
    public function testTotalPrice1()
    {
        $user = new User('John Doe','john.doe@example.com');
        $apple = new Product('Apple',4.95);
        $orange = new Product('Orange',3.99);
        $user->getShoppingCart()->addProduct($apple);
        $user->getShoppingCart()->addProduct($apple);
        $user->getShoppingCart()->addProduct($orange);
        $this->assertEquals($user->getShoppingCart()->totalPrice(), 13.89);
    }

    public function testTotalPrice2()
    {
        $user = new User('John Doe','john.doe@example.com');
        $apple = new Product('Apple',4.95);
        $user->getShoppingCart()->addProduct($apple);
        $user->getShoppingCart()->addProduct($apple);
        $user->getShoppingCart()->addProduct($apple);
        $user->getShoppingCart()->removeProduct($apple);
        $this->assertEquals($user->getShoppingCart()->totalPrice(), 9.9);
    }

}
?>
